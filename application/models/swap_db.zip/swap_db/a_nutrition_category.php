<?php
class A_Nutrition_category extends DataMapper {
    var $table = 'a_nutrition_categories';
    var $has_one = array();
    var $has_many = array('a_language','a_nutrition','a_product');    
//    var $validation = array(
//        'name' => array(
//            'label' => 'Название категрии',
//            'rules' => array('required', 'trim', 'unique')
//        )
//    );
//    
    function __construct($id = NULL){
        parent::__construct($id);
    }
    function get_full_info($id = false,$current_language = 'Russian'){        
        #svazivaet nutrition s vibranim language
        $language = new Language();
        is_numeric($current_language)?$language->get_by_id($current_language):$language->get_by_name($current_language);
        if ($id){
            $this->get_by_id($id);
            $this->language->include_join_fields()->get_iterated();
        }else{
            $this->include_join_fields()->where_in_related($language)->get_iterated();
            $this->id = null;    
        }
    }
    function save_by_language($data,$current_language = 'Russian'){        
        $language = new Language();
        is_numeric($current_language)?$language->get_by_id($current_language):$language->get_by_name($current_language);        
        #
        if(isset($data['name'])){
            $this->value = 1;
            $this->save($language);
            $this->set_join_field($language, 'name', $data['name']);
        }
        #
    }
}

/* End of file name.php */
/* Location: ./application/models/category.php */
?>